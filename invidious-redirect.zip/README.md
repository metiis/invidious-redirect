# invidious-redirect

# Now redirects to invidio.us instead of hooktube - see Hooktube changelog for details

A (very) small WebExtension to redirect YouTube links to Invidious.

I am not affiliated with YouTube or Invidious.

This work is released into the public domain. See UNLICENSE for details.
